

<!DOCTYPE html>
<html>
<head>
    <title>Login Form</title>
</head>
<body>

<h2>Login</h2>

<form action="logindisplay.php" method="post">
    <label>Username:</label>
    <input type="text" name="username" required>

    <label>Password:</label><br>
    <input type="password" name="password" required>

    <input type="submit" value="Login">
</form>

</body>
</html>

