
<footer style="text-align:center, padding:20px;">
     @copy; <?php echo date("Y"); ?> Trent Grooms
</footer>
