<?php
$isLogin = false;
$username = null;

if ($isLogin) {
    echo "<p>Welcome, $username</p>";
}
else {
    echo "<p>Please log in</p>";
}


